echo "# rilhrmodule" >> README.md
git init
git add *
git commit -m "first commit"
git remote add origin https://github.com/sabarikannan-ai/rilhrmodule.git
git push -u origin master