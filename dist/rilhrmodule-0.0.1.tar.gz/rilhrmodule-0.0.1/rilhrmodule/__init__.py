from rilhrmodule.Employee import *
from rilhrmodule.Dept import *